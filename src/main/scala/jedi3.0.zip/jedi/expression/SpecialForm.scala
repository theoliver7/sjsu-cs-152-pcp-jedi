package jedi.expression

trait SpecialForm extends Expression